
package com.example.studentcrud;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DBNAME = "StudentDB.db";

    public DBHelper(Context context) {
        super(context, DBNAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE students(" +
                "rollno INTEGER PRIMARY KEY," +
                "name TEXT," +
                "email TEXT," +
                "course TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS students");
        onCreate(db);
    }

    // Insert Record
    public boolean insertStudent(int rollno, String name, String email, String course) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("rollno", rollno);
        values.put("name", name);
        values.put("email", email);
        values.put("course", course);
        long result = db.insert("students", null, values);
        return result != -1;
    }

    // Update Record
    public boolean updateStudent(int rollno, String name, String email, String course) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("email", email);
        values.put("course", course);

        Cursor cursor = db.rawQuery("SELECT * FROM students WHERE rollno = ?", new String[]{String.valueOf(rollno)});
        if (cursor.getCount() > 0) {
            long result = db.update("students", values, "rollno=?", new String[]{String.valueOf(rollno)});
            return result != -1;
        } else {
            return false;
        }
    }

    // Delete Record
    public boolean deleteStudent(int rollno) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM students WHERE rollno = ?", new String[]{String.valueOf(rollno)});
        if (cursor.getCount() > 0) {
            long result = db.delete("students", "rollno=?", new String[]{String.valueOf(rollno)});
            return result != -1;
        } else {
            return false;
        }
    }

    // Get All Records
    public Cursor getAllStudents() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM students", null);
    }
}
