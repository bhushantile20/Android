package com.example.studentcrud;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText etRollNo, etName, etEmail, etCourse;
    Button btnAdd, btnUpdate, btnDelete, btnView;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etRollNo = findViewById(R.id.etRollNo);
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etCourse = findViewById(R.id.etCourse);
        btnAdd = findViewById(R.id.btnAdd);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnDelete = findViewById(R.id.btnDelete);
        btnView = findViewById(R.id.btnView);

        DB = new DBHelper(this);

        // Add Record
        btnAdd.setOnClickListener(v -> {
            int roll = Integer.parseInt(etRollNo.getText().toString());
            String name = etName.getText().toString();
            String email = etEmail.getText().toString();
            String course = etCourse.getText().toString();

            boolean inserted = DB.insertStudent(roll, name, email, course);
            Toast.makeText(MainActivity.this, inserted ? "Record Added" : "Failed to Add", Toast.LENGTH_SHORT).show();
        });

        // Update Record
        btnUpdate.setOnClickListener(v -> {
            int roll = Integer.parseInt(etRollNo.getText().toString());
            String name = etName.getText().toString();
            String email = etEmail.getText().toString();
            String course = etCourse.getText().toString();

            boolean updated = DB.updateStudent(roll, name, email, course);
            Toast.makeText(MainActivity.this, updated ? "Record Updated" : "Record Not Found", Toast.LENGTH_SHORT).show();
        });

        // Delete Record
        btnDelete.setOnClickListener(v -> {
            int roll = Integer.parseInt(etRollNo.getText().toString());
            boolean deleted = DB.deleteStudent(roll);
            Toast.makeText(MainActivity.this, deleted ? "Record Deleted" : "Record Not Found", Toast.LENGTH_SHORT).show();
        });

        // View Records
        btnView.setOnClickListener(v -> {
            Cursor res = DB.getAllStudents();
            if (res.getCount() == 0) {
                Toast.makeText(MainActivity.this, "No Records Found", Toast.LENGTH_SHORT).show();
                return;
            }

            StringBuilder buffer = new StringBuilder();
            while (res.moveToNext()) {
                buffer.append("Roll No: ").append(res.getInt(0)).append("\n");
                buffer.append("Name: ").append(res.getString(1)).append("\n");
                buffer.append("Email: ").append(res.getString(2)).append("\n");
                buffer.append("Course: ").append(res.getString(3)).append("\n\n");
            }

            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setCancelable(true);
            builder.setTitle("Student Records");
            builder.setMessage(buffer.toString());
            builder.show();
        });
    }
}
