package com.example.image_rotation;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    ImageView imageView;
    Button moveBtn, rotateBtn, scaleBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);
        moveBtn = findViewById(R.id.moveBtn);
        rotateBtn = findViewById(R.id.rotateBtn);
        scaleBtn = findViewById(R.id.scaleBtn);

        moveBtn.setOnClickListener(v -> {
            Animation move = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.move);
            imageView.startAnimation(move);
        });

        rotateBtn.setOnClickListener(v -> {
            Animation rotate = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.rotate);
            imageView.startAnimation(rotate);
        });

        scaleBtn.setOnClickListener(v -> {
            Animation scale = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.scale);
            imageView.startAnimation(scale);
        });
    }
}
