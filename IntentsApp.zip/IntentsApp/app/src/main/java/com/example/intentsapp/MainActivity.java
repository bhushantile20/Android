package com.example.intentsapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText etWebsite, etLocation, etMessage;
    Button btnOpenWebsite, btnOpenMap, btnShareText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // find views
        etWebsite = findViewById(R.id.etWebsite);
        etLocation = findViewById(R.id.etLocation);
        etMessage = findViewById(R.id.etMessage);

        btnOpenWebsite = findViewById(R.id.btnOpenWebsite);
        btnOpenMap = findViewById(R.id.btnOpenMap);
        btnShareText = findViewById(R.id.btnShareText);

        btnOpenWebsite.setOnClickListener(v -> openWebsite());
        btnOpenMap.setOnClickListener(v -> openLocationInMap());
        btnShareText.setOnClickListener(v -> shareText());
    }

    private void openWebsite() {
        String url = etWebsite.getText().toString().trim();
        if (TextUtils.isEmpty(url)) {
            Toast.makeText(this, "Please enter a website link", Toast.LENGTH_SHORT).show();
            return;
        }

        // Add scheme if missing
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "http://" + url;
        }

        Uri webpage = Uri.parse(url);
        Intent intent = new Intent(Intent.ACTION_VIEW, webpage);

        try {
            startActivity(Intent.createChooser(intent, "Open with"));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "No application can handle this request.", Toast.LENGTH_LONG).show();
        }
    }

    private void openLocationInMap() {
        String location = etLocation.getText().toString().trim();
        if (TextUtils.isEmpty(location)) {
            Toast.makeText(this, "Please enter a location", Toast.LENGTH_SHORT).show();
            return;
        }

        // Try geo URI first
        Uri geoUri = Uri.parse("geo:0,0?q=" + Uri.encode(location));
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, geoUri);
        mapIntent.setPackage("com.google.android.apps.maps"); // prefer Google Maps app

        try {
            // Try opening in Google Maps
            startActivity(mapIntent);
        } catch (ActivityNotFoundException e) {
            // Fallback to browser with Google Maps web URL
            Uri webUri = Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(location));
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, webUri);
            try {
                startActivity(browserIntent);
            } catch (ActivityNotFoundException ex) {
                Toast.makeText(this, "No application available to view maps.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void shareText() {
        String message = etMessage.getText().toString().trim();
        if (TextUtils.isEmpty(message)) {
            Toast.makeText(this, "Please enter a message to share", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, message);
        sendIntent.setType("text/plain");

        Intent chooser = Intent.createChooser(sendIntent, "Share via");
        try {
            startActivity(chooser);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "No app available to share text.", Toast.LENGTH_LONG).show();
        }
    }
}
